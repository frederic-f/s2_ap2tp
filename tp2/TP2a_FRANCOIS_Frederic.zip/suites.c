#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "suite_vecteur.h"

double u (unsigned int n) 
{
  if (n == 0)
    {
      return 5 ;
    }
  else
    {
      return (0.2 * (u (n-1) + 4 * v (n-1))) ;
    }
}


double v (unsigned int n) 
{
  if (n == 0)
    {
      return 1 ;
    }
  else
    {
      return (0.2 * (3* u (n -1) + 2 * v (n - 1))) ;
    }
}

void test_uv_param (unsigned int n)
{

  double lim = 19. / 7. ;
  printf ("Lim = %f\n\n", lim) ;

  // calcul u(n)
  double res_u ;
  res_u = u (n) ;

  printf ("u(%u) = ", n) ;
  printf ("%f\n", res_u) ;

  double diff_u ;

  diff_u = lim - res_u ;

  printf ("diff_u = %f\n\n", diff_u) ;



  // calcul v(n)
  double res_v ;
  res_v = v (n) ;

  printf ("v(%u) = ", n) ;
  printf ("%f\n", res_v) ;

  double diff_v ;
  diff_v = lim - res_v ;

  printf ("diff_v = %f\n", diff_v) ;

  printf ("\n") ;


}

void test_uv ()
{
  test_uv_param (10) ;

}


int main ()
{
  test_uv () ;  

  return EXIT_SUCCESS;
}
