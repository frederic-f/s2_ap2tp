#ifndef SUITE_VECTEUR

#define SUITE_VECTEUR

double u (unsigned int n) ;
double v (unsigned int n) ;

struct vecteur2D 
{
  double x ;
  double y ;
}

#endif
