#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define X_PAR_DEFAUT 0.
#define Y_PAR_DEFAUT 0.

struct Vecteur2D
{
  double x ;
  double y ;
} ;
typedef struct Vecteur2D vecteur2d ;

// SIGNATURES des operations primitives

// constructeurs
vecteur2d vecteur_nul () ;
vecteur2d ecrire_x (double x, vecteur2d vect) ;
vecteur2d ecrire_y (double y, vecteur2d vect) ;

// acces
double lire_x (vecteur2d vect) ;
double lire_y (vecteur2d vect) ;


// IMPLANTATION des operations primitives

// constructeurs
vecteur2d ecrire_x (double x, vecteur2d vect)
{
  vect.x = x ;
  return vect ;
}

vecteur2d ecrire_y (double y, vecteur2d vect)
{
  vect.y = y ;
  return vect ;
}

vecteur2d vecteur_nul ()
{
  vecteur2d vect ;
  vect = ecrire_x (X_PAR_DEFAUT, vect) ;
  vect = ecrire_y (Y_PAR_DEFAUT, vect) ;
  return vect ;
}


// acces
double lire_x (vecteur2d vect)
{
  return vect.x ;
}

double lire_y (vecteur2d vect)
{
  return vect.y ;
}
